<?php
/**
 * Zbooking System Recovery & Ghost Cleanup
 * 
 * Instructions:
 * 1. Upload this file to your WordPress root directory (where wp-config.php is).
 * 2. Access it via your browser: yourdomain.com/cleanup.php
 * 3. Once finished, DELETE this file for security.
 */

// If we are in the plugin folder, try to find wp-load relative to typical structure
$wp_load = __DIR__ . '/../../../wp-load.php';
if (!file_exists($wp_load)) {
    $wp_load = __DIR__ . '/wp-load.php'; // Maybe they moved it to root
}

if (!file_exists($wp_load)) {
    die("Error: Could not find wp-load.php. Please copy this script to your WordPress root folder where wp-config.php is and run it again.");
}

require_once($wp_load);

if (!current_user_can('manage_options')) {
    auth_redirect();
}

echo "<h2>Zbooking System Recovery</h2>";

// 1. Cleanup Active Plugins list to remove ghost entries
$active_plugins = get_option('active_plugins');
$new_list = array();
$found_ghosts = false;

foreach ($active_plugins as $p) {
    if ((strpos($p, 'osf') !== false || strpos($p, 'booking') !== false) && strpos($p, 'zbooking') === false) {
        echo "Removed ghost entry: " . esc_html($p) . "<br>";
        $found_ghosts = true;
    } else {
        $new_list[] = $p;
    }
}

if ($found_ghosts) {
    update_option('active_plugins', $new_list);
    echo "<b>Success: Ghost entries removed.</b><br>";
} else {
    echo "No ghost entries found in active plugins list.<br>";
}

// 2. Trigger Migration directly
if (function_exists('zb_create_booking_table')) {
    zb_create_booking_table();
    echo "<b>Success: Migration/Demo data injection triggered.</b><br>";
}

echo "<p>Next steps:</p>";
echo "1. Go to your <a href='".admin_url('plugins.php')."'>Plugins Page</a>.<br>";
echo "2. Activate the <b>Zbooking</b> plugin (it should now show the correct buttons).<br>";
echo "3. <b>DELETE THIS CLEANUP.PHP FILE</b> from your server now.";
